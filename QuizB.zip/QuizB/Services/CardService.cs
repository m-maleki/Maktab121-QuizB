﻿using QuizB.DAL.Repositories;
using QuizB.Contracts.Services;
using QuizB.Contracts.Repositories;

namespace QuizB.Services;
public class CardService : ICardService
{
    #region Fileds

    private readonly ICardRepository _cardRepository;

    #endregion

    #region Ctor
    public CardService()
    {
        _cardRepository = new CardRepository();
    }
    #endregion

    #region Implementations

    public string PasswordIsValid(string cardNumber, string password)
    {
        var passwordIsValid = _cardRepository.PasswordIsValid(cardNumber, password);

        if (passwordIsValid == false)
        {
            _cardRepository.SetWrongPasswordTry(cardNumber);
            var tryCount = _cardRepository.GetWrongPasswordTry(cardNumber);

            return tryCount > 3 ?
                "You have entered the wrong password 3 times. Your account is permanently blocked" :
                "Card number Or Password Is Wrong";
        }
        else
        {
            return "Welcome";
        }
    }

    public bool CardIsActive(string cardNumber, string password)
    {
        return _cardRepository.PasswordIsValid(cardNumber, password);
    }

    public bool CardHaveRequiredBalance(string cardNumber, float balance)
    {
        throw new NotImplementedException();
    }

    #endregion
}