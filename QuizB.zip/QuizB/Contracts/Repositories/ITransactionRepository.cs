﻿using QuizB.Entities;

namespace QuizB.Contracts.Repositories;
public interface ITransactionRepository
{
    void Add(Transaction transaction);
    List<Transaction> GetListOfTransactions(string cardNumber);
    float DailyWithdrawal(string cardNumber);
}