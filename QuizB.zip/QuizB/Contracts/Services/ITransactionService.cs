﻿using QuizB.Entities;

namespace QuizB.Contracts.Services;
public interface ITransactionService
{
    string TransferMoney(string sourceCardNumber, string destinationCardNumber, float amount);
    List<Transaction> GetListOfTransactions(string cardNumber);
}