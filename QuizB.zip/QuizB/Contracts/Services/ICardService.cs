﻿namespace QuizB.Contracts.Services;
public interface ICardService
{
    string PasswordIsValid(string cardNumber, string password);
    bool CardIsActive(string cardNumber, string password);
    bool CardHaveRequiredBalance(string cardNumber, float balance);

}